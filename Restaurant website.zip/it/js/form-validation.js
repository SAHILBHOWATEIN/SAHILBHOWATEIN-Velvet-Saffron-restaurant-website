document.addEventListener('DOMContentLoaded', () => {
    const reservationForm = document.getElementById('reservation-form');
    const formMessage = document.getElementById('form-message');

    if (reservationForm) {
        reservationForm.addEventListener('submit', (e) => {
            e.preventDefault();

            // Simple validation
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const date = document.getElementById('date').value;

            if (!name || !email || !date) {
                showMessage('Please fill in all required fields.', 'error');
                return;
            }

            if (!validateEmail(email)) {
                showMessage('Please enter a valid email address.', 'error');
                return;
            }

            // Simulate form submission
            showMessage('Processing your reservation...', 'info');
            
            setTimeout(() => {
                showMessage(`Thank you, ${name}! Your reservation for ${date} has been received. We will contact you shortly.`, 'success');
                reservationForm.reset();
            }, 1500);
        });
    }

    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    function showMessage(text, type) {
        formMessage.textContent = text;
        formMessage.className = ''; // Reset
        formMessage.classList.add('message', type);
        
        // Add some basic styling for messages via JS if not in CSS
        formMessage.style.padding = '1rem';
        formMessage.style.marginTop = '1rem';
        formMessage.style.borderRadius = '5px';
        
        if (type === 'error') {
            formMessage.style.backgroundColor = '#f8d7da';
            formMessage.style.color = '#721c24';
        } else if (type === 'success') {
            formMessage.style.backgroundColor = '#d4edda';
            formMessage.style.color = '#155724';
        } else {
            formMessage.style.backgroundColor = '#e2e3e5';
            formMessage.style.color = '#383d41';
        }
    }
});
